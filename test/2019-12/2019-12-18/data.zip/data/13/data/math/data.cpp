#include<bits/stdc++.h>
typedef long long LL;
int T;LL n,k,d;
LL R(){
	return 1ll*rand()+(32768ll*rand())+(32768ll*32768ll*rand())+(32768ll*32768ll*32768ll*(rand()/2));
}
LL mul(LL a,LL b,LL p){LL v=0;for(;b;a=(a+a)%p,b>>=1)if(b&1)v=(v+a)%p;return v;}
LL pw(LL a,LL b,LL p){LL v=1;for(a%=p;b;a=mul(a,a,p),b>>=1)if(b&1)v=mul(v,a,p);return v;}
void ex(LL a,LL b,LL&x,LL&y){if(!b){x=1;y=0;return;}ex(b,a%b,y,x);y-=a/b*x;}
LL GCD(LL a,LL b){if(!a)return 1;if(a<0)return GCD(-a,b);LL t;for(;b;)t=a%b,a=b,b=t;return a;}
bool ck(LL a,LL n,LL x,LL t){
    LL V=pw(a,x,n),la=V,i;
    for(i=1;i<=t;la=V,i++)if(V=mul(V,V,n),V==1&&la!=1&&la!=n-1)return 1;
    return V!=1;
}
bool mr(LL n){
    if(n<2)return 0;if(n==2)return 1;if(n%2==0)return 0;LL x=n-1,t=0,i;for(;x%2==0;x>>=1)t++;
    for(i=20;i;i--)if(ck(rand()%(n-1)+1,n,x,t))return 0;return 1;
}
int main(){
	freopen("math22.in","w",stdout);
	srand(time(0));
	for(T=100;T--;){
		for(k=R();!mr(k);k=R());
		n=R();d=R();
		printf("%lld %lld %lld\n",n,k,d);
	}
}
