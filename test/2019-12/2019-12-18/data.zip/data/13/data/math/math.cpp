#include<bits/stdc++.h>
#define M 1000000007
using namespace std;
typedef long long LL;int T,i,t,W;LL n,k,d,AN,V,q[33];
LL mul(LL a,LL b,LL p){LL v=0;for(;b;a=(a+a)%p,b>>=1)if(b&1)v=(v+a)%p;return v;}
LL pw(LL a,LL b,LL p){LL v=1;for(a%=p;b;a=mul(a,a,p),b>>=1)if(b&1)v=mul(v,a,p);return v;}
void ex(LL a,LL b,LL&x,LL&y){if(!b){x=1;y=0;return;}ex(b,a%b,y,x);y-=a/b*x;}
LL GCD(LL a,LL b){if(!a)return 1;if(a<0)return GCD(-a,b);LL t;for(;b;)t=a%b,a=b,b=t;return a;}
bool ck(LL a,LL n,LL x,LL t){
    LL V=pw(a,x,n),la=V,i;
    for(i=1;i<=t;la=V,i++)if(V=mul(V,V,n),V==1&&la!=1&&la!=n-1)return 1;
    return V!=1;
}
bool mr(LL n){
    if(n<2)return 0;if(n==2)return 1;if(n%2==0)return 0;LL x=n-1,t=0,i;for(;x%2==0;x>>=1)t++;
    for(i=20;i;i--)if(ck(rand()%(n-1)+1,n,x,t))return 0;return 1;
}
LL pr(LL x,LL c){
    LL i=1,k=2,x0=rand()%x,y=x0,d;
    for(;i++;){
        x0=(mul(x0,x0,x)+c)%x;d=GCD(y-x0,x);
        if(d!=1&&d!=x)return d;if(y==x0)return x;
        if(i==k)y=x0,k+=k;
    }
}
void ff(LL n){
    if(mr(n)){q[++t]=n;return;}
    LL p=n;for(;p>=n;)p=pr(p,rand()%(n-1)+1);
    ff(p);ff(n/p);
}

LL Pw(LL a,LL b){a%=M;LL v=1;for(;b;b>>=1,a=a*a%M)if(b&1)v=v*a%M;return v;}
LL CAL(LL a1,LL d,LL n){
	return ((a1%M)*Pw(d,n)%M-a1%M+M)*Pw(d-1,M-2)%M;
}
LL G(LL d,LL n){
	if(d==1)return (n%M)*((n+1)%M)%M*Pw(2,M-2)%M;
	return (Pw(d,n+1)*(n%M)%M-CAL(d,d,n)+M)*Pw(d-1,M-2)%M;
}
void dfs(int x,int y,LL z){
	if(x==t+1){
		V=G(Pw(d,z),n/z)*(z%M)%M;
		if(y)AN=(AN-V+M)%M;else AN=(AN+V)%M;
		return;
	}
	dfs(x+1,y,z);dfs(x+1,y^1,z*q[x]);
}
int main(){
	freopen("math25.in","r",stdin);freopen("math25.out","w",stdout);
	srand(23333);
	for(;~scanf("%lld%lld%lld",&n,&k,&d);){d%=M;
		t=0;AN=0;if(k!=1)ff(k);
    	sort(q+1,q+t+1);W=unique(q+1,q+t+1)-q-1;t=W;
    	dfs(1,0,1);printf("%lld\n",AN);
	}
}
